import React from 'react';

class Home extends React.Component {

    getData() {
        fetch('/users/getUsers')
            .then(res => res.json())
            .then((res) => {
                console.log(res);
            });
    }

    render() {
        return (
            <div>
                Home
            </div>
        )
    }
}

export default Home;