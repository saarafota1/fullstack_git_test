import React from 'react';

class Admin extends React.Component {

    render() {
        return (
            <div>
                Admin
            </div>
        )
    }
}

export default Admin;